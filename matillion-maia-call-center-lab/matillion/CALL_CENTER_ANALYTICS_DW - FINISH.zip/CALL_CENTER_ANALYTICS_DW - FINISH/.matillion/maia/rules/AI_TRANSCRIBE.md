To transcribe audio, stored in a FILE column use the following snowflake functions:

AI_TRANSCRIBE( <audio_file> )

An string containing a JSON representation of the transcription result

"audio_duration": The total duration of the audio file in seconds.

"text": The transcription of the complete audio file, provided when the timestamp_granularity field is not specified.